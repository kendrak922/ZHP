<?php
/**
 * @license GPL-2.0-only
 *
 * Modified on 30-June-2025 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace BitCode\BitFormPro\Dependencies\Mpdf\Container;

class NotFoundException extends \BitCode\BitFormPro\Dependencies\Mpdf\MpdfException
{

}
